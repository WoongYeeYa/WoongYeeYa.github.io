package ch19_network;

import java.net.*;
public class Test01_address {
	public static void main(String[] args) {
		try{
			//InetAddress addr[]=InetAddress.getAllByName("www.naver.com");
	//	InetAddress addr[]=InetAddress.getAllByName("www.daum.com");
		//InetAddress addr[]=InetAddress.getAllByName("www.google.com");
			InetAddress addr[]=InetAddress.getAllByName("www.google.co.kr");
			
			for(int i=0; i<addr.length; i++){
				System.out.println(addr[i].getHostAddress());
				System.out.println(addr[i].getHostName());
			}
		}catch(Exception e){
			System.out.println(e);
		}
	}
}//class end
