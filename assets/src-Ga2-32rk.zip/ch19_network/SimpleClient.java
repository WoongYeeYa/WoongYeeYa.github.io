package ch19_network;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class SimpleClient {
	public static void main(String[] args) {
		Socket sock = null;
		DataInputStream in = null;
		DataOutputStream out = null;
		
		String msg = "Ŭ���̾�Ʈ 192.168.0.212 ��������";
		
		try{
			sock= new Socket(args[0],5555); //���� ip, ���� port
			in = new DataInputStream(sock.getInputStream());
			System.out.println(in.readUTF());
			
			out = new DataOutputStream(sock.getOutputStream());
			out.writeUTF(msg);
		}catch(Exception e){
			
		}
	}
}
