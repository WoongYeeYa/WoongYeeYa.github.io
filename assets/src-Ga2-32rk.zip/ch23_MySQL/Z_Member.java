package ch23_mysql;

public class Z_Member {

}
