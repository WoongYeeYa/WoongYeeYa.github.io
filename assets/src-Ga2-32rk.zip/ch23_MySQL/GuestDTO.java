package ch23_MySQL;

public class GuestDTO {
	private String id; 
	private String name;
	private String email;
	private String title;
	private String content;
	
	public GuestDTO() {} // ����Ʈ ������
	public GuestDTO(String id, String name, String email, String title,
			String content) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.title = title;
		this.content = content;
	}//cons-end

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
}//class-end
