package ch04_Control;

public class Test16_for2 {
	public static void main(String[] args) {
		//����
		//*
		//* *
		//* * *
		//* * * *
		for(int a=1; a<=4; a++){
			for(int b=1; b<=a; b++)
			{
				System.out.print("* ");
			}
			System.out.println();
		}//inner for end
		//out for end
		System.out.println();
		
		//����
		//####*
		//###**
		//##***
		//#****

		for(int c=1; c<=4; c++){
			for(int d=1; d<=(5-c); d++){
				System.out.print("#");
			}
			for(int e=1; e<=c; e++){
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		//����
		//####*
		//###***
		//##*****
		//#*******
		
		for(int f=1; f<=4; f++){
			for(int g=1; g<=(5-f); g++){
				System.out.print("#");
			}
			for(int h=1; h<=(f*2-1); h++){
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		
		//������ ���
		
		for(int i=2; i<=9; i++){
			for(int j=1; j<=9; j++){
				System.out.print(" "+i+"*"+j+"="+j*i);
			}//inner for end
			
			System.out.println();
		}//out for end
		
		System.out.println();
		
		//A				//A
		//B C			//A B
		//D E F			//A B C
		//G H I J		//A B C D
		
		for(char k=65; k<=68; k++){
			
			for(char m=65; m<=k; m++){
				System.out.print(m);
			}
			System.out.println();
		}
		
		System.out.println();
		char ch='A';
		for(char k=1; k<=4; k++){
			//char ch='A';
			for(char m=1; m<=k; m++){
				System.out.print(ch);
				ch++;
			}
			System.out.println();
		}
		System.out.println();
		
		//A	
		//B C	
		//D E F
		//G H I J
	
		for(char k=65; k<=68; k++){
			for(char l=65; l<=(70-k); l++)
			{
				System.out.print(" ");
			}
			for(char m=65; m<=k; m++){
				System.out.print(m);
			}
			System.out.println();
		}

		}
	}//main end
//class end
