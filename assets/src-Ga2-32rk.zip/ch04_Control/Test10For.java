package ch04_Control;

public class Test10For {
	public static void main(String[] args) {
		//1~10�� ����Ͻÿ�
		
		for (int i=1; i<=10; i++){
			System.out.println(i+" ");
		}
		
		System.out.println();
		
		for(int i=10; i>=1; i--){
			System.out.println(i+" ");
		}
	}
}
