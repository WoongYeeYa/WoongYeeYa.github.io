package ch04_Control;

//while���� do while�� ��
public class Test19 {
	public static void main(String[] args) {
		//while
		int i = 10000; //�ʱⰪ
		while(i<=10){
			System.out.println("HI");
			i++;
		}
		
		System.out.println();
		
		//do while
		int j = 10000; //�ʱⰪ
		do{
			System.out.println("Nice");
			j++;
		}while(j<=10);
			
		
	
	}//main end
}//class end
