package ch04_Control;

public class Test15for2 {
	public static void main(String[] args) {
			//1 2 3 4
			//1 2 3 4
			//1 2 3 4
			//1 2 3 4
		
		for(int i=1; i<=4; i++){
			for(int j=1; j<=4; j++){
			System.out.print(j+" ");
			}//inner-for
			
			System.out.println();
		}//out-for
		
		System.out.println();
		
		//
		//* * * *
		//* * * *
		//* * * *
		//* * * *
		
		for(int a=1; a<=4; a++){
			

			for(int b=1; b<=4; b++){
				System.out.print("* ");
				
			}//inner-for
			System.out.println();
		}//out-for
	}
}

