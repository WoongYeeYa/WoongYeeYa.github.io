package ch04_Control;

public class Test20Break {
	public static void main(String[] args) {
		for(int i=1; i<=10000; i++){
			System.out.println("Very Good");
			if(i==10)break; //for ���� Ż�� (loopŻ��)
		}
		
		System.out.println();
		
		int j =1;
		while(j<=10000){
			System.out.println("��ſ� �ݿ���");
			if(j==5) break;
			j++;
		}

	}
}
