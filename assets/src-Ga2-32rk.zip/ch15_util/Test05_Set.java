package ch15_util;

import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
public class Test05_Set {
	public static void main(String[] args) {
		Set<String> set=new HashSet<String>();
		
		set.add("�λ��");
		set.add("�ѹ���");
		set.add("�λ��");
		set.add("ȸ��");
		set.add("���");
		
		System.out.println("size() : "+set.size());
		
	}
}
