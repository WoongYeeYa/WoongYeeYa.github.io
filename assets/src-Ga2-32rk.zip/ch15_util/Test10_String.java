package ch15_util;

public class Test10_String {
	public static void main(String[] args) {
		String s1="hello";
		String s2="hello";
		System.out.println(s1==s2);//true
		System.out.println();
		//
		String s3="Hello";
		String s4="hello";
		System.out.println(s3==s4);//false
		System.out.println();
		//
		String s5=new String("hello");
		String s6=new String("hello");
		System.out.println(s5==s6);//false
		System.out.println();
		//
		System.out.println(s5.equals(s6));//���ڿ� ��
		
	}//main-end
}//class-end
