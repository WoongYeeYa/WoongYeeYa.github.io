package ch13_exception;

public class Test02_Exception {
	public static void main(String[] args) throws Exception{
		int num = Integer.parseInt(args[0]);
		
		//if(num%0==0){
		if(num%2==0){
			System.out.println(num+"�� ¦�� �Դϴ�");
		}else{
			System.out.println(num+"�� Ȧ�� �Դϴ�");
		}
		
	}//main end
}//class end
