package ch05_Array;

public class Test01_array {
	public static void main(String[] args) {
		//�������
		int a=10;
		int b=10;
		int c=10;
		System.out.println("a:"+a);
		System.out.println("b:"+b);
		System.out.println("c:"+c);
		
		System.out.println();
		
		//�迭
		int d[]={40,50,60};
		System.out.println("�迭 ��� ���� :"+d.length);
		System.out.println("d[0]"+d[0]);
		System.out.println("d[1]"+d[1]);
		System.out.println("d[2]"+d[2]);
		System.out.println();
		
		//for�� ����Ͽ� ���
		for(int i=0; i<3; i++){
			System.out.println("d["+i+"]:"+d[i]);
		}//for end

	}//main end
}//class end
