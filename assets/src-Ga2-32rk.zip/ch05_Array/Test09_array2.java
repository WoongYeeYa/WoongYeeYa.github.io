package ch05_Array;

public class Test09_array2 {
	public static void main(String[] args) {

		double ki[][]={
				{177.7, 166.6},{188.8,155.5}
				};
		//2���� �迭�� 2�� for���� ����Ѵ�.
		for(int i=0; i<ki.length; i++){
			for(int j=0; j<ki[i].length; j++){
				System.out.print(ki[i][j]+" ");
		}//inner for
		System.out.println();

	 }


	}
}
