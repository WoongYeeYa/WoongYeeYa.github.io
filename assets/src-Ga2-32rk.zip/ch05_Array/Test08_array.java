package ch05_Array;

public class Test08_array {
	public static void main(String[] args) {
		int a[][]={
				{10,20},{30,40,50}
		};
		System.out.println("���"+a.length);//2
		System.out.println("����"+a[0].length);//2
		System.out.println("����"+a[1].length); //3


		System.out.println();
		//���
		//10 20
		//30 40 50

		for(int i=0; i<a.length; i++){
			for(int j=0; j<a[i].length; ++j){//��
				System.out.print(a[i][j]+" ");
								 //��    ��
			}//inner for end
			System.out.println();
		}//for end
	}//main end
}//class end
