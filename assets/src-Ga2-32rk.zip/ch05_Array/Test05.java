package ch05_Array;

public class Test05 {
	public static void main(String[] args) {
		int age[]={25,27,29};
		double height[]={177.7,188.8,199,9};
		String name[]={"kim","lee","park"};
		
		for(int i=0; i<age.length; i++){
			System.out.println(age[i]+"\t"+height[i]+"\t"+name[i]);
		}
	}
}
