package ch05_Array;

public class Test11_array2 {
	public static void main(String[] args) {
		//a b c
		//d e f
		//     
		//g h i
		//j k l
		
		char ch[][][]={
				{{'a','b','c'},{'d','e','f'}},
				{{'g','h','i'},{'j','k','l'}}
				};
		for(int i=0; i<2; i++){
			for(int j=0; j<2; j++){
				for(int k=0; k<3; k++){
				System.out.print(ch[i][j][k]+" ");//�౸��
									//��   ��   ��
				
				}//inner for end	
				System.out.println();
			}//middle for end
			System.out.println();//�鱸��
		}//out for end
	}
}

		
	

