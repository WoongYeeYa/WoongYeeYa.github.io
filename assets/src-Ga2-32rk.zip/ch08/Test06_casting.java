package ch08;

public class Test06_casting {
	public static void main(String[] args) {
		Super1 super1=new Super1();//
		Super1.disp();
		
		super1=new Sub1();
		super1.disp();
		
		((sub1)super1).kk();//cf:int a=(int)12.5;
	}
}
