package ch08;

public class Test02_homework {
	public static void main(String[] args) {
			
			String jumin = args[0];

			String ju = jumin.substring(7,8);
			int j = Integer.parseInt(ju);
			if(j==1||j==3){
				System.out.println(jumin+"�����Դϴ�.");
				}
			else if(j==2||j==4){
				System.out.println(jumin+"�����Դϴ�.");
			}
			
			System.out.println(args[0]);
			System.out.println(args[1]);
			System.out.println(args[2]);
			System.out.println(args[3]);
			//
			/*switch(j){
			case 1:
			case 3:
				System.out.println(jumin+"�����Դϴ�.");
				break;
			case 2:
			case 4:
				System.out.println(jumin+"�����Դϴ�.");
				break;
			}*/
	}
}
