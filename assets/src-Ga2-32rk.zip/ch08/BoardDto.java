package ch08;

public class BoardDto {
	private String id;
	private String pw;
	private String name;
	private String tel;
	private String addr;
	
	public String getId(){
		return id;
	}
}
