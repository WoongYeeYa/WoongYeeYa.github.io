package ch08;

public class Test01 {
	public static void main(String[] args) {

		String str="Good Afternoon gil-dong";
		//          01234567890123456790123 << (beginindex)

		String s1=str.substring(15);
		String s2=str.substring(5,10);
		System.out.println(s1);

		System.out.println(s2);


		String jumin = "981101-1000000";

		String j=jumin.substring(7,8);
		System.out.println(j);

		String str4="banana";
			       //012345
		int idx=str4.indexOf('a'); //'a'�� ù��°�� �߰ߵ� ��ġ�� ��´�
		System.out.println(idx);

		String str5="�� ����� $45.67";
		//           012345678901
		int idx2=str5.indexOf("$45.67");
		System.out.println("idx2:"+idx2);;//6

	}

}
