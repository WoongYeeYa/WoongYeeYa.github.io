package ch08;

//��ü �迭

class Sung{
	private String name;
	private int kor;
	private int eng;
	public Sung(){} //����Ʈ  ������


	public Sung(String name, int kor, int eng){
		this.name=name;
		this.kor=kor;
		this.eng=eng;
	}//cons end
	public void disp(){
		System.out.println(name+"  "+kor+"  "+eng+"  ");
	}
}


public class Test03_Object_array {
	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=30;
		
		Sung kim=new Sung("kim",77,88);
		Sung lee=new Sung("lee",88,99);
		Sung park=new Sung("park",99,100);
		
		kim.disp();
		lee.disp();
		park.disp();
		//����
		
		int x[]=new int[3];
		x[0]=100;
		x[1]=200;
		x[2]=300;
		
		//��ü �迭
		Sung s[]=new Sung[3]; //��ü�迭����
		s[0]=new Sung("aaa",66,77);
		s[1]=new Sung("bbb",77,88);
		s[2]=new Sung("ccc",88,99);
		
		
		//for���� ����Ͽ� ����� ����Ͻÿ�
		for(int i=0; i<s.length; i++){
			s[i].disp();
		}
		
		int y[]={30,40,50};
		
		Sung m[]={new Sung("choi",77,88),
				new Sung("An",99,100),
				new Sung("Song",88,99)};
		//for������ ����Ͻÿ�
		
		for(int j=0; j<m.length; j++){
			m[j].disp();
		}

	}
}
