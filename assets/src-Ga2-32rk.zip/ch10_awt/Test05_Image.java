package ch10_awt;

import java.awt.*;
import java.awt.event.*;

public class Test05_Image extends Frame {
	//����
	Image img;
	
	//������
	public Test05_Image(){
		super("�̹��� ");
		img=Toolkit.getDefaultToolkit().getImage("c:\\_work\\_imgs\\aa.jpg");
		addWindowListener(new MyWin());
		setSize(450,450);
		setVisible(true);
	}
	
	//inner class
	class MyWin extends WindowAdapter{
		public void windowClosing(WindowEvent we){
			System.exit(0);
		}
	}//inner class end
	
	public void paint(Graphics g){
		g.drawImage(img, 30,50,this);
		g.drawImage(img, 30,50,300,300,this);
		//g.drawImage(img, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, observer)
	}
	//main
	public static void main(String[] args) {
		new Test05_Image(); //��ü����, ������ ȣ��
	}
}//class end
