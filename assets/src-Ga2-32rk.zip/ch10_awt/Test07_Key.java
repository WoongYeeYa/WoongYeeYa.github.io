package ch10_awt;

import java.awt.*;
import java.awt.event.*;

public class Test07_Key extends Frame implements KeyListener {

	Image img;
	int x,y;
	
	public Test07_Key(){
		//super("Ű �̺�Ʈ");
		setTitle("Ű �̺�Ʈ");
		
		x=100;
		y=100;
		img=Toolkit.getDefaultToolkit().getImage("c:\\_work\\_imgs\\aa.jpg");
		addWindowListener(new MyWin());
		addKeyListener(this);
		setSize(450,450);
		setVisible(true);
	}

	//inner class
	class MyWin extends WindowAdapter{
		public void windowClosing(WindowEvent we){
			System.exit(0);
		}
	}
	
	//�޼ҵ� �������̵�
	public void keyPressed(KeyEvent ke){
		switch(ke.getKeyCode()){
		case KeyEvent.VK_UP:
			y-=5;
			break;
		case KeyEvent.VK_DOWN:
			y+=5;
			break;
		case KeyEvent.VK_LEFT:
			x-=5;
			break;
		case KeyEvent.VK_RIGHT:
			x+=5;
			break;
		}//switch end
		
		repaint();//paint ȣ��
	}//KeyPressed end
	public void paint(Graphics g){
		g.drawImage(img, x, y, this);
	}
	public void keyReleased(KeyEvent ke){}
	public void keyTyped(KeyEvent ke){}
	
	public static void main (String args[]){
		new Test07_Key();
	}
}
