package ch14_io;

import java.io.*;
public class Test09_byte_buff_wr {
	public static void main(String[] args) {
		//------���� ����------
		BufferedOutputStream bos=null;
		try{
			bos=new BufferedOutputStream(new FileOutputStream("b2.txt"));
			
			for(int i=1; i<=10; i++){
			bos.write(i);
			}//for end
		}catch(Exception e){
			System.out.println(e);
		}finally{
			try{
				bos.close();
			}catch(Exception e2){
				
			}
		}//finally end
		
		BufferedInputStream bis=null;
		try{
			bis=new BufferedInputStream(new FileInputStream("b2.txt"));
			
			int a;
			while((a=bis.read()) != -1){//���� ���� �ƴ� ���� �ݺ�����
				System.out.print(a+" ");
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{
			try{
				bis.close();
			}catch(Exception e2){}
		}
	}//main end
}//class end
