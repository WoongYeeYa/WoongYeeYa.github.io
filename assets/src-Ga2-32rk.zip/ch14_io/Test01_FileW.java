package ch14_io;
import java.io.*;
public class Test01_FileW {
	public static void main(String[] args) {
		FileWriter fw=null;
		try{
			fw=new FileWriter("a1.txt");//��ü����
			for(int i=1; i<=3; i++){
				fw.write("�ٹ�ȣ:"+i+"\n");
			}//for end

		}catch(IOException e){
			System.out.println(e);
		}finally{
			try{
				fw.close();
			}catch(Exception e2){}
		}
	}
}
