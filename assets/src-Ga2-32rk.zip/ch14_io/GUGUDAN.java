package ch14_io;

public class GUGUDAN {
	public static void main(String[] args) {

		for(int i=1; i<=9; i++){
			for(int j=2; j<=9; j++){
				System.out.print(" "+j+"*"+i+"="+j*i);
			}//inner for end
			System.out.println();
		}// out for end
	}//main end
}//class end