package ch22_Oracle;

import java.sql.*;

public class Test01_insert_pstmt {
	public static void main(String[] args) {
		String DRIVER = "jdbc.oracle.driver.OracleDriver"		
	}
}
