package ch22_Oracle;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;//select�� �� �ʿ�

import java.sql.SQLException;

//0. import java.sql.*;
//1. ����̹� �ε�
//2. Connection  DB����
//3. Statement stmt  / PreparedStatement pstmt

public class Test01_select {
	public static void main(String[] args) {
		String DRIVER="oracle.jdbc.driver.OracleDriver";
		String URL="jdbc:oracle:thin:@localhost:1521:XE";
		String USER="scott";
		String PWD="tiger";
		
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		
		try{
			Class.forName(DRIVER);//
			System.out.println("����̹��ε� ����");
		}catch(ClassNotFoundException ex){
			System.out.println("����̹��ε� ����:"+ex);
		}//catch--end
		//����
		
		try{
			con=DriverManager.getConnection(URL,USER,PWD);
			//System.out.println("DB���� ����");
			stmt=con.createStatement();//Statement ����
			rs=stmt.executeQuery("select * from member");
			
			while(rs.next()){
				String id=rs.getString("id");//"id" <= DB�� �ʵ��
				String pw=rs.getString("pw");
				String name=rs.getString("name");
				String tel=rs.getString("tel");
				String addr=rs.getString("addr");
				
				System.out.println(id+"--"+pw+"--"+name+"--"+tel+"--"+addr);
				
			}//while-end
		}catch(SQLException ex2){
			System.out.println("DB���� ����:"+ex2);
		}finally{
			try{
				if(rs != null){rs.close();}
				if(stmt != null){stmt.close();}
				if(con != null){con.close();}
				
			}catch(SQLException ex3){}
		}//finally-end
	}//main-end
}//class-end
