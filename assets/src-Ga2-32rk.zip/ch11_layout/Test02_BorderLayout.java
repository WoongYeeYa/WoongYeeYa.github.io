package ch11_layout;


import java.awt.*;
import java.awt.event.*;

public class Test02_BorderLayout extends Frame {

	//����
	Button b1,b2,b3,b4,b5;
	TextArea ta;
	//������
	public Test02_BorderLayout(){
		super("BorderLayout");
		
		b1= new Button("ù��° ��ư");
		b2= new Button("�ι�° ��ư");
		b3= new Button("����° ��ư");
		b4= new Button("�׹�° ��ư");
		b5= new Button("�ټ���° ��ư");
		
		ta = new TextArea();
		//BorderLayout�� Window�迭�� ����Ʈ�̴�
		//��ġ
		add(b1,"North");
		add(b2,"South");
		add(b3,"East");
		add(b4,"West");
		//add(b5,"Center");
		
		add(ta,"Center");
		
		addWindowListener(new MyWin());
		//setBounds(x,y,width,height);
		setBounds(100,100,500,500);
		setVisible(true);
	}//cons end
	
	//inner class
	class MyWin extends WindowAdapter{
		public void windowClosing(WindowEvent we){
			System.exit(0);
		}
	}//inner class end
	public static void main(String[] args) {
		new Test02_BorderLayout();
	}
}
