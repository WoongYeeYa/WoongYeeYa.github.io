package ch03_operation;

public class Test06 {
	public static void main(String[] args) {
		int a = 10; //��������, �ʱ갪 10 �Ҵ�
		System.out.println(a); //10

		a+=2;
		System.out.println(a);//12

		a-=2;
		System.out.println(a);//10

		a*=2;
		System.out.println(a);//20

		a/=2;
		System.out.println(a);//10

		a%=2;
		System.out.println(a);//0
	}
}
