package ch06_oop;

public class Test05_method_overload {
	public void star(){
		for(int i=1; i<=4; i++){
			for(int j=1; j<=i; j++){
				System.out.print("*");
			}//inner for
			System.out.println();
		}//out for

	}//star();

	public void star2(){
		for(int i=1; i<=4; i++){
			for(int j=1; j<=(5-i); j++){
				System.out.print(" ");
			}//inner for
			for(int k=1; k<=(i*2-1); k++){
				System.out.print("*");
			}
			System.out.println();
		}//out for
	}

	public void gugudan(){
		for(int i=1; i<=9; i++){
			for(int j=2; j<=9; j++){
				System.out.print(j+"*"+i+"="+(j*i)+"\t");
			}
			System.out.println();
		}
	}
	public static void main(String[] args){
		Test05_method_overload t=new Test05_method_overload();
		t.star();
		System.out.println();
		t.star2();
		System.out.println();
		t.gugudan();
	}

}
