package ch06_oop;

//�޼���. ���ϰ� �ޱ�
public class Test02_method {
	public int aa(){
		System.out.println("aa() called...");
		return 100;
	}//aa end
	
	public double bb(){
		System.out.println("bb() called...");
		return 12.5;
		
	}//bb end
	
	public String cc(){
		System.out.println("cc() called...");
		return "ȫ�浿";
	}//cc end
	
	public static void main(String[] args) {
		Test02_method t = new Test02_method(); //��ä����, ������ ȣ��
		int a = t.aa();
		double d = t.bb();
		String s = t.cc();
		System.out.println(a); //100
		System.out.println(d); //12.5
		System.out.println(s); //ȫ�浿
	}//main end
}//class end
