package ch16_util;
import java.util.*;

public class Test09_Hashtable {
	public static void main(String[] args) {
		Hashtable<String,String> ht=new Hashtable<String,String>();//��ü����
		//           key,value
		
		ht.put("id", "kim");
		ht.put("name", "�迬��");
		ht.put("addr", "���α� ���ε�");
		
		//���
		System.out.println(ht.get("id"));
		System.out.println(ht.get("name"));
		System.out.println(ht.get("addr"));
	}//main-end
}//class-end
