package ch16_util;
import java.util.List;
//���� for
import java.util.ArrayList;
public class Test03_for {
	public static void main(String[] args) {
		String arr[]={"kim","lee","park"};
		for(String s:arr){
			System.out.println(s);
		}//for-end
		System.out.println();
		
		List<String> list=new ArrayList<String>();//��ü����
		list.add(new String("����"));
		list.add("����");
		list.add("������");
		
		for(String s:list){
			System.out.println(s);
		}//for-end
	}//main-end
}//class-end
